<?php

echo json_encode(array('title'=>LANGUAGE_LOG_REQUEST_SUCCESS,'msg'=>LANGUAGE_NAME));

?>