<?php

echo LANGUAGE_LOG_REQUEST_SUCCESS.'<br>';
echo "当前使用的语言: ".LANGUAGE_NAME;

?>