<?php

require dirname(__FILE__).'/Database.class.php';

?>